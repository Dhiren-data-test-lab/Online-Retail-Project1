# Online Retail II — Project-1 (Sample Portfolio)

This folder contains the Project-1 sample deliverables for the Online Retail II dataset.
Files created by the assistant (automated):
- Online_Retail_Project_Summary_sample.pdf  : multi-page PDF summary (SAMPLE) with charts and key findings
- online_retail_cleaned_sample.csv          : cleaned dataset sample used for analysis
- top_products.csv                          : top products by revenue (sample)
- country_revenue.csv                       : country-level revenue (sample)
- customer_revenue.csv                      : customer revenue list (sample)
- rfm_customers_sample.csv                  : RFM sample (top customers by monetary)
